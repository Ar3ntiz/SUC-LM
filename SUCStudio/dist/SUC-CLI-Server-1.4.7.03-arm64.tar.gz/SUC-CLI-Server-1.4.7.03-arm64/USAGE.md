# SUC CLI and server

Apple Silicon / Metal binaries. The Universal macOS app is distributed separately;
Intel uses its remote-client mode. No model weights or tokenizer are bundled.
These particular standalone binaries require macOS 26.0 or later, as
recorded from their Mach-O deployment targets in BUILD.json. The separately
packaged Universal app targets macOS 15 or later; do not confuse these targets.

From this directory (replace both absolute model/tokenizer paths):

```sh
./suc1-inspect /path/model.suc1
./suc1-generate /path/model.suc1 --tokenizer /path/tokenizer.json --prompt "Hello" --steps 128
./suc1-server --help
./suc1-server /path/model.suc1 --tokenizer /path/tokenizer.json
```

The standalone server defaults to loopback and has no API-key authentication;
the app's embedded server supplies the API-key layer. Use the app server for
authenticated LAN access. Model files and tokenizers must match; existing SUC1
files are reusable.

DeepSeek/GLM automatically use qualified FP32 TCQ reuse; SUC_TCQ_REUSE=0 selects
the historical path. Other model families retain their previous kernel default.
Qwen hybrid graphs retain one bounded recurrent/convolution checkpoint (128 MiB
maximum CPU state copies); KV/indexer prefix rows remain in place. Matching chat
turns restore that prefix without changing the existing SUC template. First requests
and changes before the checkpoint still run full prefill.
SUC_PREFIX_CHECKPOINTS=0 retains strict live-prefix reuse only.
SUC_PREFIX_CACHE=0 disables both prefix policies; SUC_SAMPLING_LEGACY=1 selects
historical sampling order. Sampling CDF order can change seeded text, not its
distribution. N-gram parallelism, query tiling, half TCQ and prompt lookup are
not release defaults. MTP is not implemented. Memory policy is unchanged.

Keep the CLI automatic Qwen prefill profile and the app/server conservative
profile distinct when comparing measurements. Explicit --chunk is honored.
BUILD.json records the actual compiled revision and binary hashes.

This local distribution is not Developer-ID signed or notarized.
No installer should be run automatically during validation.
